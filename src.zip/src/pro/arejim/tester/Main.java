package pro.arejim.tester;

import pro.arejim.tester.gui.frames.Frame;

public class Main {

    public static void main(String[] args) {
        Frame.start(args);      // Просто запуск GUI
    }
}
