package pro.arejim.tester.utils;

public enum CurrentPane {
    // Окно вибора метода, метод Люка-Лемера, метод Аткина-Морейна, резулятат первого метода, результат второго метода
    SELECTION_PANE, FIRST_METHOD, SECOND_METHOD, RESULT_OF_FIRST, RESULT_OF_SECOND
}
